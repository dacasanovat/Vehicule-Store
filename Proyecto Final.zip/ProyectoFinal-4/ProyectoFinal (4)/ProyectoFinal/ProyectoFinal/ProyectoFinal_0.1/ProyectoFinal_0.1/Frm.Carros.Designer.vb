﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frm_Carros
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Frm_Carros))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Btn_Fiesta = New System.Windows.Forms.Button()
        Me.Btn_Fit = New System.Windows.Forms.Button()
        Me.Btn_Ibiza = New System.Windows.Forms.Button()
        Me.Btn_TT = New System.Windows.Forms.Button()
        Me.Btn_Mustang = New System.Windows.Forms.Button()
        Me.Btn_Camaro = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Btn_Tesla = New System.Windows.Forms.Button()
        Me.Btn_Jaguar = New System.Windows.Forms.Button()
        Me.Btn_Masseratti = New System.Windows.Forms.Button()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Tesla_ModelS = New System.Windows.Forms.PictureBox()
        Me.Jaguar_Ftype = New System.Windows.Forms.PictureBox()
        Me.Masseratti_Ghibli = New System.Windows.Forms.PictureBox()
        Me.Audi_TT = New System.Windows.Forms.PictureBox()
        Me.Ford_Mustang = New System.Windows.Forms.PictureBox()
        Me.Chevy_Camaro = New System.Windows.Forms.PictureBox()
        Me.Seat_Ibiza = New System.Windows.Forms.PictureBox()
        Me.Honda_Fit = New System.Windows.Forms.PictureBox()
        Me.Ford_Fiesta = New System.Windows.Forms.PictureBox()
        Me.btn_back = New System.Windows.Forms.Button()
        CType(Me.Tesla_ModelS, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Jaguar_Ftype, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Masseratti_Ghibli, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Audi_TT, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Ford_Mustang, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Chevy_Camaro, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat_Ibiza, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Honda_Fit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Ford_Fiesta, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(10, 61)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(14, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "B"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(10, 74)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(15, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "U"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(10, 87)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(15, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "D"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(10, 100)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(15, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "G"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(10, 113)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(14, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "E"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(10, 126)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(14, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "T"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(-7, 152)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(592, 13)
        Me.Label7.TabIndex = 9
        Me.Label7.Text = "---------------------------------------------------------------------------------" & _
    "--------------------------------------------------------------------------------" & _
    "----------------------------------"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(12, 233)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(14, 13)
        Me.Label9.TabIndex = 14
        Me.Label9.Text = "T"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(12, 220)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(15, 13)
        Me.Label10.TabIndex = 13
        Me.Label10.Text = "R"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(12, 207)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(15, 13)
        Me.Label11.TabIndex = 12
        Me.Label11.Text = "O"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(12, 194)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(14, 13)
        Me.Label12.TabIndex = 11
        Me.Label12.Text = "P"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(12, 181)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(14, 13)
        Me.Label13.TabIndex = 10
        Me.Label13.Text = "S"
        '
        'Btn_Fiesta
        '
        Me.Btn_Fiesta.Location = New System.Drawing.Point(64, 126)
        Me.Btn_Fiesta.Name = "Btn_Fiesta"
        Me.Btn_Fiesta.Size = New System.Drawing.Size(116, 23)
        Me.Btn_Fiesta.TabIndex = 15
        Me.Btn_Fiesta.Text = "Ford Fiesta"
        Me.Btn_Fiesta.UseVisualStyleBackColor = True
        '
        'Btn_Fit
        '
        Me.Btn_Fit.Location = New System.Drawing.Point(238, 126)
        Me.Btn_Fit.Name = "Btn_Fit"
        Me.Btn_Fit.Size = New System.Drawing.Size(116, 23)
        Me.Btn_Fit.TabIndex = 16
        Me.Btn_Fit.Text = "Honda Fit"
        Me.Btn_Fit.UseVisualStyleBackColor = True
        '
        'Btn_Ibiza
        '
        Me.Btn_Ibiza.Location = New System.Drawing.Point(415, 126)
        Me.Btn_Ibiza.Name = "Btn_Ibiza"
        Me.Btn_Ibiza.Size = New System.Drawing.Size(116, 23)
        Me.Btn_Ibiza.TabIndex = 17
        Me.Btn_Ibiza.Text = "Seat Ibiza"
        Me.Btn_Ibiza.UseVisualStyleBackColor = True
        '
        'Btn_TT
        '
        Me.Btn_TT.Location = New System.Drawing.Point(415, 252)
        Me.Btn_TT.Name = "Btn_TT"
        Me.Btn_TT.Size = New System.Drawing.Size(116, 23)
        Me.Btn_TT.TabIndex = 23
        Me.Btn_TT.Text = "Audi TT"
        Me.Btn_TT.UseVisualStyleBackColor = True
        '
        'Btn_Mustang
        '
        Me.Btn_Mustang.Location = New System.Drawing.Point(238, 252)
        Me.Btn_Mustang.Name = "Btn_Mustang"
        Me.Btn_Mustang.Size = New System.Drawing.Size(116, 23)
        Me.Btn_Mustang.TabIndex = 22
        Me.Btn_Mustang.Text = "Ford Mustang"
        Me.Btn_Mustang.UseVisualStyleBackColor = True
        '
        'Btn_Camaro
        '
        Me.Btn_Camaro.Location = New System.Drawing.Point(64, 252)
        Me.Btn_Camaro.Name = "Btn_Camaro"
        Me.Btn_Camaro.Size = New System.Drawing.Size(116, 23)
        Me.Btn_Camaro.TabIndex = 21
        Me.Btn_Camaro.Text = "Chevy Camaro"
        Me.Btn_Camaro.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(10, 369)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(14, 13)
        Me.Label8.TabIndex = 29
        Me.Label8.Text = "Y"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(10, 356)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(15, 13)
        Me.Label14.TabIndex = 28
        Me.Label14.Text = "R"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(10, 343)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(15, 13)
        Me.Label15.TabIndex = 27
        Me.Label15.Text = "U"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(10, 330)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(14, 13)
        Me.Label16.TabIndex = 26
        Me.Label16.Text = "X"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(10, 317)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(15, 13)
        Me.Label17.TabIndex = 25
        Me.Label17.Text = "U"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(10, 304)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(13, 13)
        Me.Label18.TabIndex = 24
        Me.Label18.Text = "L"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(-7, 278)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(592, 13)
        Me.Label19.TabIndex = 30
        Me.Label19.Text = "---------------------------------------------------------------------------------" & _
    "--------------------------------------------------------------------------------" & _
    "----------------------------------"
        '
        'Btn_Tesla
        '
        Me.Btn_Tesla.Location = New System.Drawing.Point(415, 378)
        Me.Btn_Tesla.Name = "Btn_Tesla"
        Me.Btn_Tesla.Size = New System.Drawing.Size(116, 23)
        Me.Btn_Tesla.TabIndex = 36
        Me.Btn_Tesla.Text = "Tesla Model S"
        Me.Btn_Tesla.UseVisualStyleBackColor = True
        '
        'Btn_Jaguar
        '
        Me.Btn_Jaguar.Location = New System.Drawing.Point(238, 378)
        Me.Btn_Jaguar.Name = "Btn_Jaguar"
        Me.Btn_Jaguar.Size = New System.Drawing.Size(116, 23)
        Me.Btn_Jaguar.TabIndex = 35
        Me.Btn_Jaguar.Text = "Jaguar F-Type"
        Me.Btn_Jaguar.UseVisualStyleBackColor = True
        '
        'Btn_Masseratti
        '
        Me.Btn_Masseratti.Location = New System.Drawing.Point(64, 378)
        Me.Btn_Masseratti.Name = "Btn_Masseratti"
        Me.Btn_Masseratti.Size = New System.Drawing.Size(116, 23)
        Me.Btn_Masseratti.TabIndex = 34
        Me.Btn_Masseratti.Text = "Masseratti Ghibli"
        Me.Btn_Masseratti.UseVisualStyleBackColor = True
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(-7, 27)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(592, 13)
        Me.Label20.TabIndex = 37
        Me.Label20.Text = "---------------------------------------------------------------------------------" & _
    "--------------------------------------------------------------------------------" & _
    "----------------------------------"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(244, 3)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(123, 24)
        Me.Label21.TabIndex = 38
        Me.Label21.Text = "Select a Car"
        '
        'Tesla_ModelS
        '
        Me.Tesla_ModelS.Image = Global.ProyectoFinal_0._1.My.Resources.Resources.Tesla_Model_S
        Me.Tesla_ModelS.Location = New System.Drawing.Point(402, 294)
        Me.Tesla_ModelS.Name = "Tesla_ModelS"
        Me.Tesla_ModelS.Size = New System.Drawing.Size(141, 78)
        Me.Tesla_ModelS.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Tesla_ModelS.TabIndex = 33
        Me.Tesla_ModelS.TabStop = False
        '
        'Jaguar_Ftype
        '
        Me.Jaguar_Ftype.Image = Global.ProyectoFinal_0._1.My.Resources.Resources.Jaguar_F_type
        Me.Jaguar_Ftype.Location = New System.Drawing.Point(226, 294)
        Me.Jaguar_Ftype.Name = "Jaguar_Ftype"
        Me.Jaguar_Ftype.Size = New System.Drawing.Size(141, 78)
        Me.Jaguar_Ftype.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Jaguar_Ftype.TabIndex = 32
        Me.Jaguar_Ftype.TabStop = False
        '
        'Masseratti_Ghibli
        '
        Me.Masseratti_Ghibli.Image = Global.ProyectoFinal_0._1.My.Resources.Resources.Masserati_Ghibli
        Me.Masseratti_Ghibli.Location = New System.Drawing.Point(54, 294)
        Me.Masseratti_Ghibli.Name = "Masseratti_Ghibli"
        Me.Masseratti_Ghibli.Size = New System.Drawing.Size(141, 78)
        Me.Masseratti_Ghibli.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Masseratti_Ghibli.TabIndex = 31
        Me.Masseratti_Ghibli.TabStop = False
        '
        'Audi_TT
        '
        Me.Audi_TT.Image = CType(resources.GetObject("Audi_TT.Image"), System.Drawing.Image)
        Me.Audi_TT.Location = New System.Drawing.Point(402, 168)
        Me.Audi_TT.Name = "Audi_TT"
        Me.Audi_TT.Size = New System.Drawing.Size(141, 78)
        Me.Audi_TT.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Audi_TT.TabIndex = 20
        Me.Audi_TT.TabStop = False
        '
        'Ford_Mustang
        '
        Me.Ford_Mustang.Image = Global.ProyectoFinal_0._1.My.Resources.Resources.Ford_Mustang
        Me.Ford_Mustang.Location = New System.Drawing.Point(226, 168)
        Me.Ford_Mustang.Name = "Ford_Mustang"
        Me.Ford_Mustang.Size = New System.Drawing.Size(141, 78)
        Me.Ford_Mustang.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Ford_Mustang.TabIndex = 19
        Me.Ford_Mustang.TabStop = False
        '
        'Chevy_Camaro
        '
        Me.Chevy_Camaro.Image = Global.ProyectoFinal_0._1.My.Resources.Resources.Chevrolet_Camaro
        Me.Chevy_Camaro.Location = New System.Drawing.Point(54, 168)
        Me.Chevy_Camaro.Name = "Chevy_Camaro"
        Me.Chevy_Camaro.Size = New System.Drawing.Size(141, 78)
        Me.Chevy_Camaro.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Chevy_Camaro.TabIndex = 18
        Me.Chevy_Camaro.TabStop = False
        '
        'Seat_Ibiza
        '
        Me.Seat_Ibiza.Image = Global.ProyectoFinal_0._1.My.Resources.Resources.Seat_Ibiza1
        Me.Seat_Ibiza.Location = New System.Drawing.Point(402, 43)
        Me.Seat_Ibiza.Name = "Seat_Ibiza"
        Me.Seat_Ibiza.Size = New System.Drawing.Size(141, 78)
        Me.Seat_Ibiza.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Seat_Ibiza.TabIndex = 8
        Me.Seat_Ibiza.TabStop = False
        '
        'Honda_Fit
        '
        Me.Honda_Fit.Image = Global.ProyectoFinal_0._1.My.Resources.Resources.Honda_Fit
        Me.Honda_Fit.Location = New System.Drawing.Point(226, 43)
        Me.Honda_Fit.Name = "Honda_Fit"
        Me.Honda_Fit.Size = New System.Drawing.Size(141, 78)
        Me.Honda_Fit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Honda_Fit.TabIndex = 7
        Me.Honda_Fit.TabStop = False
        '
        'Ford_Fiesta
        '
        Me.Ford_Fiesta.Image = Global.ProyectoFinal_0._1.My.Resources.Resources.Ford_Fiesta
        Me.Ford_Fiesta.Location = New System.Drawing.Point(54, 43)
        Me.Ford_Fiesta.Name = "Ford_Fiesta"
        Me.Ford_Fiesta.Size = New System.Drawing.Size(141, 78)
        Me.Ford_Fiesta.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Ford_Fiesta.TabIndex = 6
        Me.Ford_Fiesta.TabStop = False
        '
        'btn_back
        '
        Me.btn_back.Location = New System.Drawing.Point(415, 6)
        Me.btn_back.Name = "btn_back"
        Me.btn_back.Size = New System.Drawing.Size(146, 23)
        Me.btn_back.TabIndex = 39
        Me.btn_back.Text = "Back to My Account"
        Me.btn_back.UseVisualStyleBackColor = True
        '
        'Frm_Carros
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SlateGray
        Me.ClientSize = New System.Drawing.Size(573, 410)
        Me.Controls.Add(Me.btn_back)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Btn_Tesla)
        Me.Controls.Add(Me.Btn_Jaguar)
        Me.Controls.Add(Me.Btn_Masseratti)
        Me.Controls.Add(Me.Tesla_ModelS)
        Me.Controls.Add(Me.Jaguar_Ftype)
        Me.Controls.Add(Me.Masseratti_Ghibli)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Btn_TT)
        Me.Controls.Add(Me.Btn_Mustang)
        Me.Controls.Add(Me.Btn_Camaro)
        Me.Controls.Add(Me.Audi_TT)
        Me.Controls.Add(Me.Ford_Mustang)
        Me.Controls.Add(Me.Chevy_Camaro)
        Me.Controls.Add(Me.Btn_Ibiza)
        Me.Controls.Add(Me.Btn_Fit)
        Me.Controls.Add(Me.Btn_Fiesta)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Seat_Ibiza)
        Me.Controls.Add(Me.Honda_Fit)
        Me.Controls.Add(Me.Ford_Fiesta)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Frm_Carros"
        Me.Text = "Catalogue"
        CType(Me.Tesla_ModelS, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Jaguar_Ftype, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Masseratti_Ghibli, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Audi_TT, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Ford_Mustang, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Chevy_Camaro, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat_Ibiza, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Honda_Fit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Ford_Fiesta, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Ford_Fiesta As System.Windows.Forms.PictureBox
    Friend WithEvents Honda_Fit As System.Windows.Forms.PictureBox
    Friend WithEvents Seat_Ibiza As System.Windows.Forms.PictureBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Btn_Fiesta As System.Windows.Forms.Button
    Friend WithEvents Btn_Fit As System.Windows.Forms.Button
    Friend WithEvents Btn_Ibiza As System.Windows.Forms.Button
    Friend WithEvents Audi_TT As System.Windows.Forms.PictureBox
    Friend WithEvents Ford_Mustang As System.Windows.Forms.PictureBox
    Friend WithEvents Chevy_Camaro As System.Windows.Forms.PictureBox
    Friend WithEvents Btn_TT As System.Windows.Forms.Button
    Friend WithEvents Btn_Mustang As System.Windows.Forms.Button
    Friend WithEvents Btn_Camaro As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Btn_Tesla As System.Windows.Forms.Button
    Friend WithEvents Btn_Jaguar As System.Windows.Forms.Button
    Friend WithEvents Btn_Masseratti As System.Windows.Forms.Button
    Friend WithEvents Tesla_ModelS As System.Windows.Forms.PictureBox
    Friend WithEvents Jaguar_Ftype As System.Windows.Forms.PictureBox
    Friend WithEvents Masseratti_Ghibli As System.Windows.Forms.PictureBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents btn_back As System.Windows.Forms.Button

End Class
