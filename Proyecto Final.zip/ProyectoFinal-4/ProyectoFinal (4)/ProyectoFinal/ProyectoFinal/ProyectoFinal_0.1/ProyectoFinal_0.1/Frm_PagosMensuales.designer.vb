﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frm_PagosMensuales
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Frm_PagosMensuales))
        Me.Lst_months = New System.Windows.Forms.ListBox()
        Me.Lbl_months = New System.Windows.Forms.Label()
        Me.btn_buy = New System.Windows.Forms.Button()
        Me.btn_cancel = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Lbl_totalprice = New System.Windows.Forms.Label()
        Me.Jaguar_Ftype = New System.Windows.Forms.PictureBox()
        Me.Tesla_ModelS = New System.Windows.Forms.PictureBox()
        Me.Masseratti_Ghibli = New System.Windows.Forms.PictureBox()
        Me.Audi_TT = New System.Windows.Forms.PictureBox()
        Me.Ford_Mustang = New System.Windows.Forms.PictureBox()
        Me.Chevy_Camaro = New System.Windows.Forms.PictureBox()
        Me.Seat_Ibiza = New System.Windows.Forms.PictureBox()
        Me.Honda_Fit = New System.Windows.Forms.PictureBox()
        Me.Ford_Fiesta = New System.Windows.Forms.PictureBox()
        CType(Me.Jaguar_Ftype, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Tesla_ModelS, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Masseratti_Ghibli, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Audi_TT, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Ford_Mustang, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Chevy_Camaro, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat_Ibiza, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Honda_Fit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Ford_Fiesta, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Lst_months
        '
        Me.Lst_months.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.Lst_months.FormattingEnabled = True
        Me.Lst_months.Location = New System.Drawing.Point(304, 36)
        Me.Lst_months.Name = "Lst_months"
        Me.Lst_months.Size = New System.Drawing.Size(198, 238)
        Me.Lst_months.TabIndex = 0
        '
        'Lbl_months
        '
        Me.Lbl_months.AutoSize = True
        Me.Lbl_months.Location = New System.Drawing.Point(353, 14)
        Me.Lbl_months.Name = "Lbl_months"
        Me.Lbl_months.Size = New System.Drawing.Size(92, 13)
        Me.Lbl_months.TabIndex = 1
        Me.Lbl_months.Text = "Monthly payments"
        '
        'btn_buy
        '
        Me.btn_buy.Location = New System.Drawing.Point(370, 324)
        Me.btn_buy.Name = "btn_buy"
        Me.btn_buy.Size = New System.Drawing.Size(75, 23)
        Me.btn_buy.TabIndex = 4
        Me.btn_buy.Text = "Buy Car"
        Me.btn_buy.UseVisualStyleBackColor = True
        '
        'btn_cancel
        '
        Me.btn_cancel.Location = New System.Drawing.Point(13, 9)
        Me.btn_cancel.Name = "btn_cancel"
        Me.btn_cancel.Size = New System.Drawing.Size(75, 23)
        Me.btn_cancel.TabIndex = 5
        Me.btn_cancel.Text = "Cancel"
        Me.btn_cancel.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(301, 289)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(60, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Total price:"
        '
        'Lbl_totalprice
        '
        Me.Lbl_totalprice.AutoSize = True
        Me.Lbl_totalprice.Location = New System.Drawing.Point(377, 289)
        Me.Lbl_totalprice.Name = "Lbl_totalprice"
        Me.Lbl_totalprice.Size = New System.Drawing.Size(109, 13)
        Me.Lbl_totalprice.TabIndex = 7
        Me.Lbl_totalprice.Text = "PRECIO COMPLETO"
        '
        'Jaguar_Ftype
        '
        Me.Jaguar_Ftype.Image = Global.ProyectoFinal_0._1.My.Resources.Resources.Jaguar_F_type
        Me.Jaguar_Ftype.Location = New System.Drawing.Point(13, 86)
        Me.Jaguar_Ftype.Name = "Jaguar_Ftype"
        Me.Jaguar_Ftype.Size = New System.Drawing.Size(268, 168)
        Me.Jaguar_Ftype.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Jaguar_Ftype.TabIndex = 50
        Me.Jaguar_Ftype.TabStop = False
        '
        'Tesla_ModelS
        '
        Me.Tesla_ModelS.Image = Global.ProyectoFinal_0._1.My.Resources.Resources.Tesla_Model_S
        Me.Tesla_ModelS.Location = New System.Drawing.Point(13, 86)
        Me.Tesla_ModelS.Name = "Tesla_ModelS"
        Me.Tesla_ModelS.Size = New System.Drawing.Size(268, 168)
        Me.Tesla_ModelS.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Tesla_ModelS.TabIndex = 51
        Me.Tesla_ModelS.TabStop = False
        '
        'Masseratti_Ghibli
        '
        Me.Masseratti_Ghibli.Image = Global.ProyectoFinal_0._1.My.Resources.Resources.Masserati_Ghibli
        Me.Masseratti_Ghibli.Location = New System.Drawing.Point(13, 86)
        Me.Masseratti_Ghibli.Name = "Masseratti_Ghibli"
        Me.Masseratti_Ghibli.Size = New System.Drawing.Size(268, 168)
        Me.Masseratti_Ghibli.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Masseratti_Ghibli.TabIndex = 49
        Me.Masseratti_Ghibli.TabStop = False
        '
        'Audi_TT
        '
        Me.Audi_TT.Image = CType(resources.GetObject("Audi_TT.Image"), System.Drawing.Image)
        Me.Audi_TT.Location = New System.Drawing.Point(13, 86)
        Me.Audi_TT.Name = "Audi_TT"
        Me.Audi_TT.Size = New System.Drawing.Size(268, 168)
        Me.Audi_TT.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Audi_TT.TabIndex = 48
        Me.Audi_TT.TabStop = False
        '
        'Ford_Mustang
        '
        Me.Ford_Mustang.Image = Global.ProyectoFinal_0._1.My.Resources.Resources.Ford_Mustang
        Me.Ford_Mustang.Location = New System.Drawing.Point(13, 86)
        Me.Ford_Mustang.Name = "Ford_Mustang"
        Me.Ford_Mustang.Size = New System.Drawing.Size(268, 168)
        Me.Ford_Mustang.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Ford_Mustang.TabIndex = 47
        Me.Ford_Mustang.TabStop = False
        '
        'Chevy_Camaro
        '
        Me.Chevy_Camaro.Image = Global.ProyectoFinal_0._1.My.Resources.Resources.Chevrolet_Camaro
        Me.Chevy_Camaro.Location = New System.Drawing.Point(12, 86)
        Me.Chevy_Camaro.Name = "Chevy_Camaro"
        Me.Chevy_Camaro.Size = New System.Drawing.Size(268, 168)
        Me.Chevy_Camaro.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Chevy_Camaro.TabIndex = 46
        Me.Chevy_Camaro.TabStop = False
        '
        'Seat_Ibiza
        '
        Me.Seat_Ibiza.Image = Global.ProyectoFinal_0._1.My.Resources.Resources.Seat_Ibiza1
        Me.Seat_Ibiza.Location = New System.Drawing.Point(12, 86)
        Me.Seat_Ibiza.Name = "Seat_Ibiza"
        Me.Seat_Ibiza.Size = New System.Drawing.Size(268, 168)
        Me.Seat_Ibiza.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Seat_Ibiza.TabIndex = 45
        Me.Seat_Ibiza.TabStop = False
        '
        'Honda_Fit
        '
        Me.Honda_Fit.Image = Global.ProyectoFinal_0._1.My.Resources.Resources.Honda_Fit
        Me.Honda_Fit.Location = New System.Drawing.Point(13, 86)
        Me.Honda_Fit.Name = "Honda_Fit"
        Me.Honda_Fit.Size = New System.Drawing.Size(268, 168)
        Me.Honda_Fit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Honda_Fit.TabIndex = 44
        Me.Honda_Fit.TabStop = False
        '
        'Ford_Fiesta
        '
        Me.Ford_Fiesta.Image = Global.ProyectoFinal_0._1.My.Resources.Resources.Ford_Fiesta
        Me.Ford_Fiesta.Location = New System.Drawing.Point(13, 86)
        Me.Ford_Fiesta.Name = "Ford_Fiesta"
        Me.Ford_Fiesta.Size = New System.Drawing.Size(268, 168)
        Me.Ford_Fiesta.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Ford_Fiesta.TabIndex = 43
        Me.Ford_Fiesta.TabStop = False
        '
        'Frm_PagosMensuales
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SlateGray
        Me.ClientSize = New System.Drawing.Size(563, 359)
        Me.Controls.Add(Me.Jaguar_Ftype)
        Me.Controls.Add(Me.Tesla_ModelS)
        Me.Controls.Add(Me.Masseratti_Ghibli)
        Me.Controls.Add(Me.Audi_TT)
        Me.Controls.Add(Me.Ford_Mustang)
        Me.Controls.Add(Me.Chevy_Camaro)
        Me.Controls.Add(Me.Seat_Ibiza)
        Me.Controls.Add(Me.Honda_Fit)
        Me.Controls.Add(Me.Ford_Fiesta)
        Me.Controls.Add(Me.Lbl_totalprice)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btn_cancel)
        Me.Controls.Add(Me.btn_buy)
        Me.Controls.Add(Me.Lbl_months)
        Me.Controls.Add(Me.Lst_months)
        Me.Name = "Frm_PagosMensuales"
        Me.Text = "Payment Summary"
        CType(Me.Jaguar_Ftype, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Tesla_ModelS, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Masseratti_Ghibli, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Audi_TT, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Ford_Mustang, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Chevy_Camaro, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat_Ibiza, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Honda_Fit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Ford_Fiesta, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Lst_months As System.Windows.Forms.ListBox
    Friend WithEvents Lbl_months As System.Windows.Forms.Label
    Friend WithEvents btn_buy As System.Windows.Forms.Button
    Friend WithEvents btn_cancel As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Lbl_totalprice As System.Windows.Forms.Label
    Friend WithEvents Jaguar_Ftype As System.Windows.Forms.PictureBox
    Friend WithEvents Tesla_ModelS As System.Windows.Forms.PictureBox
    Friend WithEvents Masseratti_Ghibli As System.Windows.Forms.PictureBox
    Friend WithEvents Audi_TT As System.Windows.Forms.PictureBox
    Friend WithEvents Ford_Mustang As System.Windows.Forms.PictureBox
    Friend WithEvents Chevy_Camaro As System.Windows.Forms.PictureBox
    Friend WithEvents Seat_Ibiza As System.Windows.Forms.PictureBox
    Friend WithEvents Honda_Fit As System.Windows.Forms.PictureBox
    Friend WithEvents Ford_Fiesta As System.Windows.Forms.PictureBox

End Class
