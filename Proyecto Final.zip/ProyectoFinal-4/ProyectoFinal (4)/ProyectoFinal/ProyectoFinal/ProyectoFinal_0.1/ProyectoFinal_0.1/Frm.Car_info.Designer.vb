﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frm_Info
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Frm_Info))
        Me.Tesla_ModelS = New System.Windows.Forms.PictureBox()
        Me.Jaguar_Ftype = New System.Windows.Forms.PictureBox()
        Me.Masseratti_Ghibli = New System.Windows.Forms.PictureBox()
        Me.Audi_TT = New System.Windows.Forms.PictureBox()
        Me.Ford_Mustang = New System.Windows.Forms.PictureBox()
        Me.Chevy_Camaro = New System.Windows.Forms.PictureBox()
        Me.Seat_Ibiza = New System.Windows.Forms.PictureBox()
        Me.Honda_Fit = New System.Windows.Forms.PictureBox()
        Me.Ford_Fiesta = New System.Windows.Forms.PictureBox()
        Me.Lbl_SelectedCar = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Lbl_Price = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Lbl_InterestRate = New System.Windows.Forms.Label()
        Me.Rdo_3years = New System.Windows.Forms.RadioButton()
        Me.Rdo_2year = New System.Windows.Forms.RadioButton()
        Me.Rdo_1year = New System.Windows.Forms.RadioButton()
        Me.Btn_submit = New System.Windows.Forms.Button()
        Me.Btn_back = New System.Windows.Forms.Button()
        CType(Me.Tesla_ModelS, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Jaguar_Ftype, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Masseratti_Ghibli, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Audi_TT, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Ford_Mustang, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Chevy_Camaro, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat_Ibiza, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Honda_Fit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Ford_Fiesta, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Tesla_ModelS
        '
        Me.Tesla_ModelS.Image = Global.ProyectoFinal_0._1.My.Resources.Resources.Tesla_Model_S
        Me.Tesla_ModelS.Location = New System.Drawing.Point(29, 46)
        Me.Tesla_ModelS.Name = "Tesla_ModelS"
        Me.Tesla_ModelS.Size = New System.Drawing.Size(247, 141)
        Me.Tesla_ModelS.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Tesla_ModelS.TabIndex = 42
        Me.Tesla_ModelS.TabStop = False
        '
        'Jaguar_Ftype
        '
        Me.Jaguar_Ftype.Image = Global.ProyectoFinal_0._1.My.Resources.Resources.Jaguar_F_type
        Me.Jaguar_Ftype.Location = New System.Drawing.Point(29, 46)
        Me.Jaguar_Ftype.Name = "Jaguar_Ftype"
        Me.Jaguar_Ftype.Size = New System.Drawing.Size(247, 141)
        Me.Jaguar_Ftype.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Jaguar_Ftype.TabIndex = 41
        Me.Jaguar_Ftype.TabStop = False
        '
        'Masseratti_Ghibli
        '
        Me.Masseratti_Ghibli.Image = Global.ProyectoFinal_0._1.My.Resources.Resources.Masserati_Ghibli
        Me.Masseratti_Ghibli.Location = New System.Drawing.Point(29, 46)
        Me.Masseratti_Ghibli.Name = "Masseratti_Ghibli"
        Me.Masseratti_Ghibli.Size = New System.Drawing.Size(247, 141)
        Me.Masseratti_Ghibli.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Masseratti_Ghibli.TabIndex = 40
        Me.Masseratti_Ghibli.TabStop = False
        '
        'Audi_TT
        '
        Me.Audi_TT.Image = CType(resources.GetObject("Audi_TT.Image"), System.Drawing.Image)
        Me.Audi_TT.Location = New System.Drawing.Point(29, 46)
        Me.Audi_TT.Name = "Audi_TT"
        Me.Audi_TT.Size = New System.Drawing.Size(247, 141)
        Me.Audi_TT.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Audi_TT.TabIndex = 39
        Me.Audi_TT.TabStop = False
        '
        'Ford_Mustang
        '
        Me.Ford_Mustang.Image = Global.ProyectoFinal_0._1.My.Resources.Resources.Ford_Mustang
        Me.Ford_Mustang.Location = New System.Drawing.Point(29, 46)
        Me.Ford_Mustang.Name = "Ford_Mustang"
        Me.Ford_Mustang.Size = New System.Drawing.Size(247, 141)
        Me.Ford_Mustang.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Ford_Mustang.TabIndex = 38
        Me.Ford_Mustang.TabStop = False
        '
        'Chevy_Camaro
        '
        Me.Chevy_Camaro.Image = Global.ProyectoFinal_0._1.My.Resources.Resources.Chevrolet_Camaro
        Me.Chevy_Camaro.Location = New System.Drawing.Point(29, 46)
        Me.Chevy_Camaro.Name = "Chevy_Camaro"
        Me.Chevy_Camaro.Size = New System.Drawing.Size(247, 141)
        Me.Chevy_Camaro.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Chevy_Camaro.TabIndex = 37
        Me.Chevy_Camaro.TabStop = False
        '
        'Seat_Ibiza
        '
        Me.Seat_Ibiza.Image = Global.ProyectoFinal_0._1.My.Resources.Resources.Seat_Ibiza1
        Me.Seat_Ibiza.Location = New System.Drawing.Point(29, 46)
        Me.Seat_Ibiza.Name = "Seat_Ibiza"
        Me.Seat_Ibiza.Size = New System.Drawing.Size(247, 141)
        Me.Seat_Ibiza.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Seat_Ibiza.TabIndex = 36
        Me.Seat_Ibiza.TabStop = False
        '
        'Honda_Fit
        '
        Me.Honda_Fit.Image = Global.ProyectoFinal_0._1.My.Resources.Resources.Honda_Fit
        Me.Honda_Fit.Location = New System.Drawing.Point(29, 46)
        Me.Honda_Fit.Name = "Honda_Fit"
        Me.Honda_Fit.Size = New System.Drawing.Size(247, 141)
        Me.Honda_Fit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Honda_Fit.TabIndex = 35
        Me.Honda_Fit.TabStop = False
        '
        'Ford_Fiesta
        '
        Me.Ford_Fiesta.Image = Global.ProyectoFinal_0._1.My.Resources.Resources.Ford_Fiesta
        Me.Ford_Fiesta.Location = New System.Drawing.Point(29, 46)
        Me.Ford_Fiesta.Name = "Ford_Fiesta"
        Me.Ford_Fiesta.Size = New System.Drawing.Size(247, 141)
        Me.Ford_Fiesta.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Ford_Fiesta.TabIndex = 34
        Me.Ford_Fiesta.TabStop = False
        '
        'Lbl_SelectedCar
        '
        Me.Lbl_SelectedCar.AutoSize = True
        Me.Lbl_SelectedCar.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_SelectedCar.Location = New System.Drawing.Point(40, 13)
        Me.Lbl_SelectedCar.Name = "Lbl_SelectedCar"
        Me.Lbl_SelectedCar.Size = New System.Drawing.Size(148, 25)
        Me.Lbl_SelectedCar.TabIndex = 43
        Me.Lbl_SelectedCar.Text = "Selected Car"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(314, 79)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(85, 20)
        Me.Label1.TabIndex = 44
        Me.Label1.Text = "Total Cost:"
        '
        'Lbl_Price
        '
        Me.Lbl_Price.AutoSize = True
        Me.Lbl_Price.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Price.Location = New System.Drawing.Point(314, 99)
        Me.Lbl_Price.Name = "Lbl_Price"
        Me.Lbl_Price.Size = New System.Drawing.Size(118, 20)
        Me.Lbl_Price.TabIndex = 45
        Me.Lbl_Price.Text = "Precio del carro"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Lbl_InterestRate)
        Me.GroupBox1.Controls.Add(Me.Rdo_3years)
        Me.GroupBox1.Controls.Add(Me.Rdo_2year)
        Me.GroupBox1.Controls.Add(Me.Rdo_1year)
        Me.GroupBox1.Location = New System.Drawing.Point(74, 193)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(226, 99)
        Me.GroupBox1.TabIndex = 46
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Payment"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(126, 30)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(66, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Interest rate:"
        '
        'Lbl_InterestRate
        '
        Me.Lbl_InterestRate.AutoSize = True
        Me.Lbl_InterestRate.Location = New System.Drawing.Point(126, 43)
        Me.Lbl_InterestRate.Name = "Lbl_InterestRate"
        Me.Lbl_InterestRate.Size = New System.Drawing.Size(85, 13)
        Me.Lbl_InterestRate.TabIndex = 3
        Me.Lbl_InterestRate.Text = "Current Int. Rate"
        '
        'Rdo_3years
        '
        Me.Rdo_3years.AutoSize = True
        Me.Rdo_3years.Location = New System.Drawing.Point(6, 66)
        Me.Rdo_3years.Name = "Rdo_3years"
        Me.Rdo_3years.Size = New System.Drawing.Size(56, 17)
        Me.Rdo_3years.TabIndex = 2
        Me.Rdo_3years.TabStop = True
        Me.Rdo_3years.Text = "3 Year"
        Me.Rdo_3years.UseVisualStyleBackColor = True
        '
        'Rdo_2year
        '
        Me.Rdo_2year.AutoSize = True
        Me.Rdo_2year.Location = New System.Drawing.Point(7, 43)
        Me.Rdo_2year.Name = "Rdo_2year"
        Me.Rdo_2year.Size = New System.Drawing.Size(61, 17)
        Me.Rdo_2year.TabIndex = 1
        Me.Rdo_2year.TabStop = True
        Me.Rdo_2year.Text = "2 Years"
        Me.Rdo_2year.UseVisualStyleBackColor = True
        '
        'Rdo_1year
        '
        Me.Rdo_1year.AutoSize = True
        Me.Rdo_1year.Location = New System.Drawing.Point(7, 20)
        Me.Rdo_1year.Name = "Rdo_1year"
        Me.Rdo_1year.Size = New System.Drawing.Size(56, 17)
        Me.Rdo_1year.TabIndex = 0
        Me.Rdo_1year.TabStop = True
        Me.Rdo_1year.Text = "1 Year"
        Me.Rdo_1year.UseVisualStyleBackColor = True
        '
        'Btn_submit
        '
        Me.Btn_submit.Location = New System.Drawing.Point(357, 253)
        Me.Btn_submit.Name = "Btn_submit"
        Me.Btn_submit.Size = New System.Drawing.Size(75, 23)
        Me.Btn_submit.TabIndex = 47
        Me.Btn_submit.Text = "Submit"
        Me.Btn_submit.UseVisualStyleBackColor = True
        '
        'Btn_back
        '
        Me.Btn_back.Location = New System.Drawing.Point(372, 12)
        Me.Btn_back.Name = "Btn_back"
        Me.Btn_back.Size = New System.Drawing.Size(75, 23)
        Me.Btn_back.TabIndex = 48
        Me.Btn_back.Text = "Back"
        Me.Btn_back.UseVisualStyleBackColor = True
        '
        'Frm_Info
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SlateGray
        Me.ClientSize = New System.Drawing.Size(459, 296)
        Me.Controls.Add(Me.Btn_back)
        Me.Controls.Add(Me.Btn_submit)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Lbl_Price)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Lbl_SelectedCar)
        Me.Controls.Add(Me.Jaguar_Ftype)
        Me.Controls.Add(Me.Tesla_ModelS)
        Me.Controls.Add(Me.Masseratti_Ghibli)
        Me.Controls.Add(Me.Audi_TT)
        Me.Controls.Add(Me.Ford_Mustang)
        Me.Controls.Add(Me.Chevy_Camaro)
        Me.Controls.Add(Me.Seat_Ibiza)
        Me.Controls.Add(Me.Honda_Fit)
        Me.Controls.Add(Me.Ford_Fiesta)
        Me.Name = "Frm_Info"
        Me.Text = "Car Page"
        CType(Me.Tesla_ModelS, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Jaguar_Ftype, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Masseratti_Ghibli, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Audi_TT, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Ford_Mustang, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Chevy_Camaro, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat_Ibiza, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Honda_Fit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Ford_Fiesta, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Tesla_ModelS As System.Windows.Forms.PictureBox
    Friend WithEvents Jaguar_Ftype As System.Windows.Forms.PictureBox
    Friend WithEvents Masseratti_Ghibli As System.Windows.Forms.PictureBox
    Friend WithEvents Audi_TT As System.Windows.Forms.PictureBox
    Friend WithEvents Ford_Mustang As System.Windows.Forms.PictureBox
    Friend WithEvents Chevy_Camaro As System.Windows.Forms.PictureBox
    Friend WithEvents Seat_Ibiza As System.Windows.Forms.PictureBox
    Friend WithEvents Honda_Fit As System.Windows.Forms.PictureBox
    Friend WithEvents Ford_Fiesta As System.Windows.Forms.PictureBox
    Friend WithEvents Lbl_SelectedCar As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Price As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Lbl_InterestRate As System.Windows.Forms.Label
    Friend WithEvents Rdo_3years As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_2year As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_1year As System.Windows.Forms.RadioButton
    Friend WithEvents Btn_submit As System.Windows.Forms.Button
    Friend WithEvents Btn_back As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
End Class
